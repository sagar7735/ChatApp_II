import React from 'react'
import { useState } from 'react'

function useGetAllUser() {
const [alluser,setAllUser]=useState()
}

export default useGetAllUser